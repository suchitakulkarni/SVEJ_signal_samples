# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 14.1.0 for Mac OS X x86 (64-bit) (July 16, 2024)
# Date: Fri 18 Jul 2025 09:59:39


from object_library import all_couplings, Coupling

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot



